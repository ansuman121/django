from django.contrib import admin
from mini_blog.models import icoder , Contacts , BlogPost

# Register your models here.
admin.site.register(icoder)
admin.site.register(Contacts)
admin.site.register(BlogPost)

